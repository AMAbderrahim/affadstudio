
  # Affiliate Ad Studio (Copy) (Copy)

  This is a code bundle for Affiliate Ad Studio (Copy) (Copy). The original project is available at https://www.figma.com/design/kzRTIGfuXwOJDcSqsRhCfN/Affiliate-Ad-Studio--Copy---Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  